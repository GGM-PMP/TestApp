//
//  DatosViewController.swift
//  AKSwiftSlideMenu
//
//  Created by Grisell Gomez Mondragon on 31/01/18.
//  Copyright © 2018 Kode. All rights reserved.
//

import UIKit

class DatosViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource{
    
    let personas = ["Alumno" ,"Persona Fisica", "Persona Moral", "Otros"]
    

    
    @IBOutlet weak var pickPersona: UIPickerView!
    @IBOutlet weak var btnSelectionPersona: UIButton!
    
    @IBAction func btnSelectPersona(_ sender: UIButton) {
     
        
        if pickPersona.isHidden {
            pickPersona.isHidden = false 
        }
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return personas[row]
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return personas.count
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //lblPersona.text = personas[row]
        btnSelectionPersona.setTitle(personas[row], for: .normal)
        pickPersona.isHidden = true
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickPersona.isHidden=true
        pickPersona.delegate = self
        pickPersona.dataSource = self
        
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
