//
//  Datos.swift
//  AKSwiftSlideMenu
//
//  Created by Grisell Gomez Mondragon on 31/01/18.
//  Copyright © 2018 Kode. All rights reserved.
//

import Foundation
