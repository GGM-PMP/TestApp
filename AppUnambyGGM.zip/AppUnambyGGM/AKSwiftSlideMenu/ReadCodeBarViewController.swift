//
//  ReadCodeBarViewController.swift
//  AKSwiftSlideMenu
//
//  Created by Grisell Gomez Mondragon on 23/01/18.
//  Copyright © 2018 Kode. All rights reserved.
//

import UIKit
import AVFoundation

protocol VCFinalDelegate {
    func finishPassing(update: String)
}

class ReadCodeBarViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate {
    
    @IBOutlet weak var viewScan: UIView!
    
    var delegate: VCFinalDelegate?
    
    var video = AVCaptureVideoPreviewLayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let session = AVCaptureSession()
        
        let captureDevice = AVCaptureDevice.default(for: AVMediaType.video)
        
        do{
            let input = try AVCaptureDeviceInput (device: captureDevice!)
            session.addInput(input)
        }catch{
            print("ERROR")
        }
        
        
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        output.metadataObjectTypes = [AVMetadataObject.ObjectType.qr, AVMetadataObject.ObjectType.code93]
        video = AVCaptureVideoPreviewLayer (session: session)
        video.frame = viewScan.layer.bounds
        viewScan.layer.addSublayer(video)
        
        //self.viewCode.bringSubview(toFront: squere)
        
        session.startRunning()
        
        // Do any additional setup after loading the view.
    }
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if (metadataObjects != nil && metadataObjects.count != 0) {
            if let object = metadataObjects[0] as? AVMetadataMachineReadableCodeObject {
                if object.type == AVMetadataObject.ObjectType.qr {
                    
                    /*txtFieldFactura.text = object.stringValue*/
                    
                    /*delegate?.finishPassing(string: (object.stringValue)!)*/
                    
                    delegate?.finishPassing(update: object.stringValue!)
                    
                    let alert = UIAlertController(title: "Your code is:", message: object.stringValue, preferredStyle: .alert)
                    /*alert.addAction(UIAlertAction(title: "Retake", style: .default, handler: nil))*/
                    alert.addAction(UIAlertAction(title: "Copy", style: .default, handler: { (nil) in
                        UIPasteboard.general.string = object.stringValue
                    }))
                    present(alert, animated: true, completion: nil)
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
