//
//  HomeVC.swift
//  AKSwiftSlideMenu
//
//  Created by MAC-186 on 4/8/16.
//  Copyright © 2016 Kode. All rights reserved.
//

import UIKit
import AVFoundation

class HomeVC: BaseViewController,UITextFieldDelegate, VCFinalDelegate{
    
    func finishPassing(update: String) {
        txtTicket.text = nil
        txtTicket.text = update
    }
   
    @IBOutlet weak var txtRfcValidate: UITextField!
    @IBOutlet weak var txtTicket: UITextField!
    @IBOutlet weak var txtRfc: UITextField!
    @IBOutlet weak var rdoButtonFactura: DLRadioButton!
    @IBOutlet weak var lblRfc: UILabel!
    @IBOutlet weak var btnEnviar: UIButton!
    
    
    @IBAction func btnTicketDidChange(_ sender: Any) {
        if (validateUno(text: txtTicket.text!)){
            btnEnviar.isHidden = false
        }else{
            btnEnviar.isHidden = true
        }
    }
    @IBAction func btnRfcDidChange(_ sender: Any) {
        
        if (validateDos(text: txtRfc.text!)){
            btnEnviar.isHidden = false
        }else{
            btnEnviar.isHidden = true
        }
    }
    @IBAction func btnEnviar(_ sender: Any) {
        print ("aqui cambia")
    }
    
    func validateUno(text: String) -> Bool {
        
        var result = false
        
        if text.count >= 5 && txtRfc.text?.count != 0{
            result = true
            btnEnviar.isHidden = false
        }
        
        return result
    }
    
    func validateDos(text: String) -> Bool {
        
        var result = false
        
        if text.count >= 12 && txtTicket.text?.count != 0{
            result = true
            btnEnviar.isHidden = false
        }
        

        /*if text.count >= 12{
            result = true
            btnEnviar.isHidden = false
        }*/
        
        return result
    }
    
    @IBAction func btnPerfomSegue(_ sender: Any) {
        performSegue(withIdentifier: "VCInitialToVCFinal", sender: nil)
    }
    
    @IBAction func rdoBtnQueHacer(_ sender: DLRadioButton) {
        if sender.tag == 1{
            lblRfc.text = "RFC"
            txtRfc.text=nil
            txtTicket.text = nil
            txtTicket.placeholder = "*TC#"
            txtRfc.placeholder = "ej. AAAA121231ZZZ"
            btnEnviar.isHidden = true
            //self.txtRfc.isHidden = false
            //print("Factura")
        }else{
            lblRfc.text = "EMAIL"
            txtRfc.text=nil
            txtTicket.text = nil
            txtTicket.placeholder = "*TC#"
            txtRfc.placeholder = "ej. tucorreo@ejemplo.com"
            btnEnviar.isHidden=true
            //self.txtRfc.isHidden = true
            //print("Reenviar")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.title="Home"
        addSlideMenuButton()
        
        txtRfc.autocapitalizationType = .allCharacters
        self.txtTicket.delegate = self
        self.txtRfc.delegate = self
        btnEnviar.isHidden = true
        
        let url = URL(string: "http://api.fixer.io/latest")
        
        let task = URLSession.shared.dataTask(with: url!){ (data,responde,error) in
            if error != nil
            {
                print("Error Json ¡")
            }
            else
            {
                if let content = data
                {
                    do {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)
                            print(myJson)
                    }
                    catch
                    {
                        
                    }
                }
            }
        }.resume()
    
        /*let jsonURL = "http://192.168.5.23/wscfdspruebas/consultaTicket_json.php"
        
        let url = URL(string: jsonURL)
        
        URLSession.shared.dataTask(with: url!){ (data,responde,error) in
            
            do{
              self.tickets = try JSONDecoder().decode([Ticket].self, from: data!)
                
                for eachTicket in self.tickets {
                    print(eachTicket.dependencia + eachTicket.folio_cfs)
                }
            }catch{
                print("Error")
            }
        }.resume()*/
        
        // Do any additional setup after loading the view.
    
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtTicket.resignFirstResponder()
        txtRfc.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
    
        let currentCharacterCount = textField.text?.characters.count ?? 0
        
        if (range.length + range.location > currentCharacterCount){
            return false
            
        }
        let newLength = currentCharacterCount + string.characters.count - range.length
        
        var maxLength = 0

        
        if textField.isEqual(txtRfc) {
            maxLength = 13
            
            
            
        } else if textField.isEqual(txtTicket) {
            maxLength = 20

        }
        
        return newLength <= maxLength
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? ReadCodeBarViewController{
            destination.delegate = self
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
